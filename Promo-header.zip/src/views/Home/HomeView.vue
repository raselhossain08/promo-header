<script setup>
import LeftBar from './components/LeftBar.vue'
import RightBar from './components/RightBar.vue'
</script>

<template>
  <main>
    <!-- top-bar -->
    <div class="flex items-center justify-center w-full h-10 text-center bg-black">
      <p class="pb-0 text-lg text-white">Promo Header</p>
    </div>

    <!-- Side-bar -->
    <div class="flex flex-row">
      <div class="border-black basis-2/4 border-e">
        <LeftBar />
      </div>
      <div class="basis-2/4">
        <RightBar/>
      </div>
    </div>
  </main>
</template>
